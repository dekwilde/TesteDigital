<div class="options sec_pag_options"> 
	<?php echo tfuse_qtranslate(get_option(PREFIX.'_middle_box_1')) ?>
	<?php echo tfuse_qtranslate(get_option(PREFIX.'_middle_box_2')) ?>
	<?php echo tfuse_qtranslate(get_option(PREFIX.'_middle_box_3')) ?>
	<div class="clear_container"></div>
</div>
