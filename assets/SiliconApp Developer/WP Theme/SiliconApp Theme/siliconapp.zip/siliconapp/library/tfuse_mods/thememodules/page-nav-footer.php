<?php
wp_nav_menu( array('depth' => 1, 'container_class' => '', 'menu_class' => 'footer_links', 'menu_id' => '', 'fallback_cb' => 'default_menu', 'theme_location' => 'bottom' ) );
?>