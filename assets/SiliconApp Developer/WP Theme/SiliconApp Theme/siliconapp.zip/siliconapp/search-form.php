<div class="search-box widget">
<p><?php _e('Search ', 'tfuse'); ?></p>
            <form method="get" id=" " class="searchform " action="<?php bloginfo('url'); ?>">
			<div class="input_blog">
				<div class="input_left_blog"></div>
                <input type="text" class="input_middle_blog" name="s" id="s"  value="<?php _e('Type and press enter', 'tfus') ?>" onfocus="if (this.value == '<?php _e('Type and press enter', 'tfuse') ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php _e('Type and press enter', 'tfuse') ?>';}" />
				<div class="input_right_blog"></div>
				<div class="clear_container"></div>
			</div>
             </form>
</div>
<div style="clear:both;"></div>
<!-- box -->
 